package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection connection;

    private DBConnection() {
    }

    public static Connection getConnection() {
        if (connection == null) {
            String hostname = "localhost";
            String port = "3306";
            String dbName = "mydb";
            String username = "root";
            String password = "";

            String connectionString = "jdbc:mysql://" + hostname + ":" + port + "/" + dbName;

            try {
                connection = DriverManager.getConnection(connectionString, username, password);
            } catch (SQLException e) {
                e.printStackTrace(); // Handle or log the exception appropriately
            }
        }
        return connection;
    }
}
