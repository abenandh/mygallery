package exception;

public class ArtWorkNotFoundException extends Exception {
    public ArtWorkNotFoundException(String message) {
        super(message);
    }
}
