package dao;

import entity.Gallery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GalleryDAOImpl implements IGalleryDAO {
    private Connection connection;

    public GalleryDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public boolean addGallery(Gallery gallery){
        String query = "INSERT INTO Gallery (Name, Description, Location, Curator, OpeningHours) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, gallery.getName());
            statement.setString(2, gallery.getDescription());
            statement.setString(3, gallery.getLocation());
            statement.setInt(4, gallery.getCuratorID());
            statement.setString(5, gallery.getOpeningHours());

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public boolean updateGallery(Gallery gallery) {
        String query = "UPDATE Gallery SET Name=?, Description=?, Location=?, Curator=?, OpeningHours=? WHERE GalleryID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, gallery.getName());
            statement.setString(2, gallery.getDescription());
            statement.setString(3, gallery.getLocation());
            statement.setInt(4, gallery.getCuratorID());
            statement.setString(5, gallery.getOpeningHours());
            statement.setInt(6, gallery.getGalleryID());

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public boolean removeGallery(int galleryID) {
        String query = "DELETE FROM Gallery WHERE GalleryID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, galleryID);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public Gallery getGalleryById(int galleryID) {
        String query = "SELECT * FROM Gallery WHERE GalleryID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, galleryID);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Map the result set to a Gallery object
                Gallery gallery = new Gallery();
                gallery.setGalleryID(resultSet.getInt("GalleryID"));
                gallery.setName(resultSet.getString("Name"));
                gallery.setDescription(resultSet.getString("Description"));
                gallery.setLocation(resultSet.getString("Location"));
                gallery.setCuratorID(resultSet.getInt("Curator"));
                gallery.setOpeningHours(resultSet.getString("OpeningHours"));
                return gallery;
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    @Override
    public List<Gallery> getAllGalleries() {
        List<Gallery> galleries = new ArrayList<>();
        String query = "SELECT * FROM Gallery";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                // Map each result set to a Gallery object
                Gallery gallery = new Gallery();
                gallery.setGalleryID(resultSet.getInt("GalleryID"));
                gallery.setName(resultSet.getString("Name"));
                gallery.setDescription(resultSet.getString("Description"));
                gallery.setLocation(resultSet.getString("Location"));
                gallery.setCuratorID(resultSet.getInt("Curator"));
                gallery.setOpeningHours(resultSet.getString("OpeningHours"));
                galleries.add(gallery);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return galleries;
    }
}
