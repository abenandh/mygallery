package dao;

import entity.User;

import java.sql.*;

interface UserDAO {
    boolean registerUser(User user);
}

public class UserDAOImpl implements UserDAO {

    private Connection connection;
    public UserDAOImpl(Connection connection) {
        this.connection = connection;
    }
    @Override
    public boolean registerUser(User user) {

        String query = "INSERT INTO User (Username, FirstName, LastName, Email, Password, RegistrationDate) VALUES (?, ?, ?, ?, ?, NOW())";
        try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getFirstName());
            statement.setString(3, user.getLastName());
            statement.setString(4, user.getEmail());
            statement.setString(5, user.getPassword());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    user.setUserID(generatedKeys.getInt(1));
                    return true;
                }
            }
        } catch (SQLException e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.err.println("Username or Email already exists. Please choose a different one.");
            } else {
                e.printStackTrace(); // Handle or log other exceptions appropriately
            }
        }
        return false;
    }

    public User loginUser(String username, String password) {
        String query = "SELECT * FROM User WHERE Username=? AND Password=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Map the result set to a User object
                User user = new User();
                user.setUserID(resultSet.getInt("UserID"));
                user.setUsername(resultSet.getString("Username"));
                user.setFirstName(resultSet.getString("FirstName"));
                user.setLastName(resultSet.getString("LastName"));
                user.setEmail(resultSet.getString("Email"));
                user.setPassword(resultSet.getString("Password"));
                // ... set other user details ...

                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

}
