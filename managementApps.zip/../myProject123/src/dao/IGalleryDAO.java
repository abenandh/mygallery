package dao;

import entity.Gallery;

import java.util.List;

public interface IGalleryDAO {
    boolean addGallery(Gallery gallery);

    boolean updateGallery(Gallery gallery);

    boolean removeGallery(int galleryID);

    Gallery getGalleryById(int galleryID);

    List<Gallery> getAllGalleries();
}
