package dao;

import entity.Artwork;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VirtualArtGalleryImpl implements IVirtualArtGallery {
    private Connection connection;

    public VirtualArtGalleryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public boolean addArtwork(Artwork artwork) {
        String query = "INSERT INTO Artwork (Title, Description, CreationDate, Medium, ImageURL) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, artwork.getTitle());
            statement.setString(2, artwork.getDescription());
            statement.setString(3, artwork.getCreationDate());
            statement.setString(4, artwork.getMedium());
            statement.setString(5, artwork.getImageURL());

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public boolean updateArtwork(Artwork artwork) {
        String query = "UPDATE Artwork SET Title=?, Description=?, CreationDate=?, Medium=?, ImageURL=? WHERE ArtworkID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, artwork.getTitle());
            statement.setString(2, artwork.getDescription());
            statement.setString(3, artwork.getCreationDate());
            statement.setString(4, artwork.getMedium());
            statement.setString(5, artwork.getImageURL());
            statement.setInt(6, artwork.getArtworkID());

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public boolean removeArtwork(int artworkID) {
        String query = "DELETE FROM Artwork WHERE ArtworkID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, artworkID);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public Artwork getArtworkById(int artworkID) {
        String query = "SELECT * FROM Artwork WHERE ArtworkID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, artworkID);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Map the result set to an Artwork object
                Artwork artwork = new Artwork();
                artwork.setArtworkID(resultSet.getInt("ArtworkID"));
                artwork.setTitle(resultSet.getString("Title"));
                artwork.setDescription(resultSet.getString("Description"));
                artwork.setCreationDate(resultSet.getString("CreationDate"));
                artwork.setMedium(resultSet.getString("Medium"));
                artwork.setImageURL(resultSet.getString("ImageURL"));
                return artwork;
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    @Override
    public List<Artwork> searchArtworks(String keyword) {
        List<Artwork> artworks = new ArrayList<>();
        String query = "SELECT * FROM Artwork WHERE Title LIKE ? OR Description LIKE ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, "%" + keyword + "%");
            statement.setString(2, "%" + keyword + "%");

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                // Map each result set to an Artwork object
                Artwork artwork = new Artwork();
                artwork.setArtworkID(resultSet.getInt("ArtworkID"));
                artwork.setTitle(resultSet.getString("Title"));
                artwork.setDescription(resultSet.getString("Description"));
                artwork.setCreationDate(resultSet.getString("CreationDate"));
                artwork.setMedium(resultSet.getString("Medium"));
                artwork.setImageURL(resultSet.getString("ImageURL"));
                artworks.add(artwork);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return artworks;
    }

    @Override
    public boolean addArtworkToFavorite(int userId, int artworkId) {
        String query = "INSERT INTO User_Favorite_Artwork (UserID, ArtworkID) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            statement.setInt(2, artworkId);

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public boolean removeArtworkFromFavorite(int userId, int artworkId) {
        String query = "DELETE FROM User_Favorite_Artwork WHERE UserID=? AND ArtworkID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            statement.setInt(2, artworkId);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    @Override
    public List<Artwork> getUserFavoriteArtworks(int userId) {
        List<Artwork> favoriteArtworks = new ArrayList<>();
        String query = "SELECT A.* FROM Artwork A " +
                "JOIN User_Favorite_Artwork UFA ON A.ArtworkID = UFA.ArtworkID " +
                "WHERE UFA.UserID=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                // Map each result set to an Artwork object
                Artwork artwork = new Artwork();
                artwork.setArtworkID(resultSet.getInt("ArtworkID"));
                artwork.setTitle(resultSet.getString("Title"));
                artwork.setDescription(resultSet.getString("Description"));
                artwork.setCreationDate(resultSet.getString("CreationDate"));
                artwork.setMedium(resultSet.getString("Medium"));
                artwork.setImageURL(resultSet.getString("ImageURL"));
                favoriteArtworks.add(artwork);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return favoriteArtworks;
    }
}