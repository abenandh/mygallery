package main;

import dao.GalleryDAOImpl;
import dao.UserDAOImpl;
import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import entity.Gallery;

import entity.User;
import util.DBConnection;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final VirtualArtGalleryImpl artGalleryService = new VirtualArtGalleryImpl(DBConnection.getConnection());
    private static final Scanner scanner = new Scanner(System.in);
    private static final GalleryDAOImpl galleryDAO = new GalleryDAOImpl(DBConnection.getConnection());
    private static final UserDAOImpl userDAO = new UserDAOImpl(DBConnection.getConnection());


    public static void main(String[] args) {

        boolean logOutStatus = false;
        while(true) {

            System.out.println("********** Welcome to Our App **********");
            System.out.println("1. Create Account");
            System.out.println("2. Sign-In");
            System.out.println("3. Exit");
            System.out.println("********** ****************** **********");

            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    registerUser(userDAO, scanner);
                    break;
                case 2:
                    logOutStatus = loginUser(userDAO, scanner);
                    break;
                case 3:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");

            }

            while (logOutStatus) {
                System.out.println("Virtual Art Gallery Menu:");
                System.out.println("1. Add Artwork");
                System.out.println("2. Update Artwork");
                System.out.println("3. Remove Artwork");
                System.out.println("4. Get Artwork by ID");
                System.out.println("5. Search Artworks");
                System.out.println("6. Add Artwork to Favorites");
                System.out.println("7. Remove Artwork from Favorites");
                System.out.println("8. View Favorite Artworks");
                System.out.println("9. Add Gallery");
                System.out.println("10. Update Gallery");
                System.out.println("11. Remove Gallery");
                System.out.println("12. Get Gallery by ID");
                System.out.println("13. View All Galleries");
                System.out.println("0. Logout");

                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1:
                        addArtwork();
                        break;
                    case 2:
                        updateArtwork();
                        break;
                    case 3:
                        removeArtwork();
                        break;
                    case 4:
                        getArtworkById();
                        break;
                    case 5:
                        searchArtworks();
                        break;
                    case 6:
                        addArtworkToFavorite();
                        break;
                    case 7:
                        removeArtworkFromFavorite();
                        break;
                    case 8:
                        viewFavoriteArtworks();
                        break;
                    case 9:
                        addGallery(galleryDAO, scanner);
                        break;
                    case 10:
                        updateGallery(galleryDAO, scanner);
                        break;
                    case 11:
                        removeGallery(galleryDAO, scanner);
                        break;
                    case 12:
                        getGalleryById(galleryDAO, scanner);
                        break;
                    case 13:
                        viewAllGalleries(galleryDAO);
                        break;
                    case 0:
                        System.out.println("Logging Out from the Virtual Art Gallery. Goodbye!");
                        logOutStatus = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                }
            }

        }
    }

    private static boolean loginUser(UserDAOImpl userDAO, Scanner scanner) {
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        User loggedInUser = userDAO.loginUser(username, password);

        if (loggedInUser != null) {
            System.out.println("Login successful. Welcome, " + loggedInUser.getFirstName() + "!");
            return true;
        } else {
            System.out.println("Login failed. Please check your credentials and try again.");
            return false;
        }
    }

    private static void registerUser(UserDAOImpl userDAO, Scanner scanner) {
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        User newUser = new User();
        newUser.setUsername(username);
        newUser.setFirstName(firstName);
        newUser.setLastName(lastName);
        newUser.setEmail(email);
        newUser.setPassword(password);

        if (userDAO.registerUser(newUser)) {
            System.out.println("Registration successful. User ID: " + newUser.getUserID());
        } else {
            System.out.println("Registration failed. Please try again.");
        }
    }
    private static void addArtwork() {
        // Gather input for creating an Artwork object
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        System.out.print("Enter creation date: ");
        String creationDate = scanner.nextLine();
        System.out.print("Enter medium: ");
        String medium = scanner.nextLine();
        System.out.print("Enter image URL: ");
        String imageURL = scanner.nextLine();

        // Create an Artwork object
        Artwork artwork = new Artwork();
        artwork.setTitle(title);
        artwork.setDescription(description);
        artwork.setCreationDate(creationDate);
        artwork.setMedium(medium);
        artwork.setImageURL(imageURL);

        // Call the service method to add the artwork
        boolean success = artGalleryService.addArtwork(artwork);

        if (success) {
            System.out.println("Artwork added successfully.");
        } else {
            System.out.println("Failed to add artwork. Please try again.");
        }
    }

    private static void removeGallery(GalleryDAOImpl galleryDAO, Scanner scanner) {
        System.out.print("Enter Gallery ID to remove: ");
        int galleryID = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        if (galleryDAO.removeGallery(galleryID)) {
            System.out.println("Gallery removed successfully.");
        } else {
            System.out.println("Failed to remove the gallery. Please try again.");
        }
    }

    private static void getGalleryById(GalleryDAOImpl galleryDAO, Scanner scanner) {
        System.out.print("Enter Gallery ID to retrieve: ");
        int galleryID = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        Gallery gallery = galleryDAO.getGalleryById(galleryID);
        if (gallery != null) {
            System.out.println("Retrieved Gallery: " + gallery);
        } else {
            System.out.println("Gallery with ID " + galleryID + " not found.");
        }
    }

    private static void viewAllGalleries(GalleryDAOImpl galleryDAO) {
        List<Gallery> galleries = galleryDAO.getAllGalleries();
        if (galleries.isEmpty()) {
            System.out.println("No galleries found.");
        } else {
            System.out.println("List of Galleries:");
            for (Gallery gallery : galleries) {
                System.out.println(gallery);
            }
        }
    }


    private static void updateArtwork() {
        System.out.print("Enter Artwork ID to update: ");
        int artworkID = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Check if the artwork exists before updating
        Artwork existingArtwork = artGalleryService.getArtworkById(artworkID);

        // If the artwork exists, proceed with the update
        System.out.println("Updating Artwork with ID " + artworkID);

        // Gather updated information for the artwork
        System.out.print("Enter new title: ");
        String newTitle = scanner.nextLine();
        System.out.print("Enter new description: ");
        String newDescription = scanner.nextLine();
        System.out.print("Enter new creation date: ");
        String newCreationDate = scanner.nextLine();
        System.out.print("Enter new medium: ");
        String newMedium = scanner.nextLine();
        System.out.print("Enter new image URL: ");
        String newImageURL = scanner.nextLine();

        // Create an Artwork object with the updated information
        Artwork updatedArtwork = new Artwork();
        updatedArtwork.setArtworkID(artworkID);
        updatedArtwork.setTitle(newTitle);
        updatedArtwork.setDescription(newDescription);
        updatedArtwork.setCreationDate(newCreationDate);
        updatedArtwork.setMedium(newMedium);
        updatedArtwork.setImageURL(newImageURL);

        // Call the service method to update the artwork
        boolean success = artGalleryService.updateArtwork(updatedArtwork);

        if (success) {
            System.out.println("Artwork updated successfully.");
        } else {
            System.out.println("Failed to update artwork. Please try again.");
        }
    }


    private static void removeArtwork() {
        System.out.print("Enter Artwork ID to remove: ");
        int artworkID = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Check if the artwork exists before removing
        Artwork existingArtwork = artGalleryService.getArtworkById(artworkID);

        // If the artwork exists, proceed with the removal
        System.out.println("Removing Artwork with ID " + artworkID);

        // Call the service method to remove the artwork
        boolean success = artGalleryService.removeArtwork(artworkID);

        if (success) {
            System.out.println("Artwork removed successfully.");
        } else {
            System.out.println("Failed to remove artwork. Please try again.");
        }
    }


    private static void getArtworkById() {
        System.out.print("Enter Artwork ID: ");
        int artworkID = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        Artwork artwork = artGalleryService.getArtworkById(artworkID);
        System.out.println("Retrieved Artwork: " + artwork);
    }

    private static void searchArtworks() {
        System.out.print("Enter keyword to search artworks: ");
        String keyword = scanner.nextLine();

        // Call the service method to search for artworks
        List<Artwork> searchResults = artGalleryService.searchArtworks(keyword);

        if (!searchResults.isEmpty()) {
            System.out.println("Search results:");
            for (Artwork artwork : searchResults) {
                System.out.println(artwork); // Assuming you have overridden toString() in Artwork class
            }
        } else {
            System.out.println("No artworks found for the given keyword.");
        }
    }

    private static void addArtworkToFavorite() {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        System.out.print("Enter Artwork ID to add to favorites: ");
        int artworkId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Call the service method to add the artwork to favorites
        boolean success = artGalleryService.addArtworkToFavorite(userId, artworkId);

        if (success) {
            System.out.println("Artwork added to favorites successfully.");
        } else {
            System.out.println("Failed to add artwork to favorites. Please try again.");
        }
    }

    private static void removeArtworkFromFavorite() {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        System.out.print("Enter Artwork ID to remove from favorites: ");
        int artworkId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Call the service method to remove the artwork from favorites
        boolean success = artGalleryService.removeArtworkFromFavorite(userId, artworkId);

        if (success) {
            System.out.println("Artwork removed from favorites successfully.");
        } else {
            System.out.println("Failed to remove artwork from favorites. Please try again.");
        }
    }

    private static void viewFavoriteArtworks() {
        System.out.print("Enter User ID to view favorite artworks: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Call the service method to get the user's favorite artworks
        List<Artwork> favoriteArtworks = artGalleryService.getUserFavoriteArtworks(userId);

        if (!favoriteArtworks.isEmpty()) {
            System.out.println("Favorite artworks:");
            for (Artwork artwork : favoriteArtworks) {
                System.out.println(artwork); // Assuming you have overridden toString() in Artwork class
            }
        } else {
            System.out.println("No favorite artworks found for the given user.");
        }
    }

    private static void addGallery(GalleryDAOImpl galleryDAO, Scanner scanner) {
        System.out.println("Enter Gallery details:");
        Gallery gallery = new Gallery();
        System.out.print("Name: ");
        gallery.setName(scanner.nextLine());
        System.out.print("Description: ");
        gallery.setDescription(scanner.nextLine());
        System.out.print("Location: ");
        gallery.setLocation(scanner.nextLine());
        System.out.print("Curator ID (Reference to ArtistID): ");
        gallery.setCuratorID(scanner.nextInt());
        scanner.nextLine(); // Consume the newline character
        System.out.print("Opening Hours: ");
        gallery.setOpeningHours(scanner.nextLine());

        if (galleryDAO.addGallery(gallery)) {
            System.out.println("Gallery added successfully.");
        } else {
            System.out.println("Failed to add the gallery. Please try again.");
        }
    }

    private static void updateGallery(GalleryDAOImpl galleryDAO, Scanner scanner) {
        System.out.print("Enter Gallery ID to update: ");
        int galleryID = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        Gallery existingGallery = galleryDAO.getGalleryById(galleryID);
        if (existingGallery != null) {
            System.out.println("Enter new Gallery details:");
            Gallery updatedGallery = new Gallery();
            updatedGallery.setGalleryID(existingGallery.getGalleryID());
            System.out.print("Name: ");
            updatedGallery.setName(scanner.nextLine());
            System.out.print("Description: ");
            updatedGallery.setDescription(scanner.nextLine());
            System.out.print("Location: ");
            updatedGallery.setLocation(scanner.nextLine());
            System.out.print("Curator ID (Reference to ArtistID): ");
            updatedGallery.setCuratorID(scanner.nextInt());
            scanner.nextLine(); // Consume the newline character
            System.out.print("Opening Hours: ");
            updatedGallery.setOpeningHours(scanner.nextLine());

            if (galleryDAO.updateGallery(updatedGallery)) {
                System.out.println("Gallery updated successfully.");
            } else {
                System.out.println("Failed to update the gallery. Please try again.");
            }
        } else {
            System.out.println("Gallery with ID " + galleryID + " not found.");
        }
    }

}
